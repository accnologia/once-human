
# Once Human Landing Page

A simple HTML landing page to promote and link to a content locker for the game "Once Human".

## Usage

Just upload this folder to your static site host (e.g., Vercel, GitHub Pages).
